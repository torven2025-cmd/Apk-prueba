/* Clan Clash 3D - capa cartoon (Three.js). Proyección afín idéntica a la del 2D => input/cámara intactos. */
(function(){
if(!window.THREE){console.warn('three.js no cargó: modo 2D');return}
const T=THREE,K=22,wrapEl=cv.parentElement,R={ok:0};
let ren;try{ren=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'})}catch(e){return}
const c3=ren.domElement;c3.id='c3';wrapEl.insertBefore(c3,cv);
const st=document.createElement('style');st.textContent='#c3{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none;pointer-events:none}canvas#c{background:transparent!important}.wrap{background:radial-gradient(ellipse at 50% 40%,#4fd3e8,#1b8fc9 60%,#0d5a9a)}';document.head.appendChild(st);
const scene=new T.Scene(),cam3=new T.PerspectiveCamera();cam3.matrixWorldInverse.identity();
scene.add(new T.HemisphereLight(0xdff4ff,0x7a9a45,.95));
const sun=new T.DirectionalLight(0xfff0cc,1.05);sun.position.set(40,12,60);scene.add(sun);
const gm=new T.DataTexture(new Uint8Array([110,190,255]),3,1,T.LuminanceFormat);gm.minFilter=gm.magFilter=T.NearestFilter;gm.needsUpdate=true;
const MC={},mat=(c,em)=>MC[c+'_'+em]||(MC[c+'_'+em]=new T.MeshToonMaterial({color:c,gradientMap:gm,side:T.DoubleSide,emissive:em||0x000000}));
const OUT=new T.MeshBasicMaterial({color:0x1a0f05,side:T.FrontSide});/* proyección invertida: FrontSide = casco trasero */
function put(g,geo,c,x,y,z,o){const m=new T.Mesh(geo,mat(c,o&&o.em));m.position.set(x,y,z);if(!o||o.ol!==0){const l=new T.Mesh(geo,OUT);l.scale.setScalar(1.09);m.add(l)}g.add(m);return m}
const bx=(g,w,d,h,x,y,z,c,o)=>put(g,new T.BoxGeometry(w,d,h),c,x,y,z+h/2,o);
const cy=(g,a,b,h,x,y,z,c,o)=>{const q=new T.CylinderGeometry(a,b,h,16);q.rotateX(Math.PI/2);return put(g,q,c,x,y,z+h/2,o)};
const cn=(g,r,h,x,y,z,c,sg,o)=>{const q=new T.ConeGeometry(r,h,sg||16);q.rotateX(Math.PI/2);if(sg==4)q.rotateZ(Math.PI/4);return put(g,q,c,x,y,z+h/2,o)};
const sp=(g,r,x,y,z,c,o)=>put(g,new T.SphereGeometry(r,14,10),c,x,y,z,o);
const spin=[],wave=[];
function flag(g,x,y,z,c){cy(g,.025,.025,.7,x,y,z,0x6b4626,{ol:0});const f=bx(g,.34,.02,.22,x+.18,y,z+.55,c,{ol:0});wave.push(f)}
const MODEL={
hall(g,b){bx(g,2.5,2.5,.8,0,0,0,0xd8c79c);bx(g,1.8,1.8,.7,0,0,.8,0xcdb88a);cn(g,1.5,1,0,0,1.5,0xd43c2b,4);
 for(const[a,c]of[[1,1],[1,-1],[-1,1],[-1,-1]]){cy(g,.26,.3,1.1,a*1.1,c*1.1,0,0xbfae86);cn(g,.38,.55,a*1.1,c*1.1,1.1,0xe0482f)}
 bx(g,.6,.08,.7,0,1.26,0,0x6b4626);sp(g,.2,0,0,2.55,0xffd24a,{em:0x553300});flag(g,0,0,2.55,0xffd24a)},
mine(g,b){cy(g,1.05,1.1,.12,0,0,0,0x6b4a2a);const r=sp(g,.8,0,0,.2,0x8d8f95);r.scale.z=.7;
 for(const[x,y]of[[.5,.6],[-.5,.5],[.7,-.3]]){const n=sp(g,.2,x,y,.25,0xffd24a,{em:0x664400});spin.push(n)}
 bx(g,.6,.4,.25,-.6,-.55,.1,0x8a5a2b);cy(g,.14,.14,.06,-.8,-.4,.05,0x333);cy(g,.14,.14,.06,-.4,-.4,.05,0x333)},
pump(g,b){cy(g,.75,.8,.9,0,0,0,0x7a54a8);cy(g,.8,.8,.12,0,0,.35,0xffd24a);const o=sp(g,.45,0,0,1.2,0xe46bff,{em:0x771a99});spin.push(o);
 cy(g,.1,.1,.9,.8,.4,.1,0x8d8f95);cy(g,.1,.1,.9,-.7,-.5,.1,0x8d8f95)},
gst(g,b){bx(g,1.8,1.8,.5,0,0,0,0x8a6a3e);for(let i=0;i<4;i++)cy(g,.55-i*.08,.55-i*.08,.16,0,0,.5+i*.15,0xffd24a,{em:0x442b00});
 for(const[x,y]of[[.6,.6],[-.6,.5],[.5,-.6]])cy(g,.22,.22,.22,x,y,.5,0xf5b820,{em:0x442b00});sp(g,.18,0,0,1.2,0xfff09a,{em:0x886600})},
est(g,b){cy(g,.85,.9,1.2,0,0,0,0x8e44ad);for(const z of[.25,.85])cy(g,.92,.92,.1,0,0,z,0xffd24a);const d=sp(g,.85,0,0,1.2,0xb066d6);d.scale.z=.5;sp(g,.2,0,0,1.8,0xff8aff,{em:0x992a99})},
rax(g,b){bx(g,1.7,1.7,.9,0,0,0,0xc9a36a);cn(g,1.6,.9,0,0,.9,0x2f7fb8,4);bx(g,.5,.08,.6,0,.86,0,0x5a3a1a);flag(g,.7,.7,.9,0xf2603b);bx(g,.1,.1,.5,-.7,.7,.9,0xc4ccd6)},
camp(g,b){cy(g,1.05,1.1,.08,0,0,0,0x5a8a3a);cn(g,.65,.95,-.45,-.4,.05,0xe0b060,4);cn(g,.55,.8,.1,.55,.05,0xd9503f,4);
 const f=cn(g,.2,.45,.35,-.3,.1,0xff8a1f,8,{em:0xaa4400,ol:0});wave.push(f);bx(g,.4,.08,.08,.35,-.3,.1,0x6b4626)},
scout(g,b){cy(g,.5,.62,1.9,0,0,0,0x8d7aa8);cy(g,.72,.72,.14,0,0,1.9,0x6b4626);cn(g,.8,.8,0,0,2.04,0x7a4fb0,16);flag(g,0,0,2.84,0xb07aff)},
hut(g,b){bx(g,1.2,1.2,.6,0,0,0,0xb98a52);cn(g,1.1,.9,0,0,.6,0xa0522d,4);bx(g,.35,.06,.45,0,.62,0,0x4a2a10)},
cannon(g,b){cy(g,.75,.85,.5,0,0,0,0x9a9a9f);const q=cy(g,.2,.26,1,.1,0,.8,0x2b2b30);q.rotation.y=Math.PI/2-.35;q.position.x=.45;sp(g,.28,-.1,0,.8,0x2b2b30);
 for(const y of[-.5,.5])cy(g,.22,.22,.1,0,y,.3,0x6b4626).rotation.x=Math.PI/2},
tower(g,b){cy(g,.5,.7,1.9,0,0,0,0xa8896a);for(let i=0;i<8;i++){const a=i*.785;bx(g,.2,.2,.18,Math.cos(a)*.62,Math.sin(a)*.62,1.9,0x8c6a45)}
 cy(g,.5,.5,.1,0,0,1.9,0x6b4626);sp(g,.17,0,0,2.2,0xf2c8a0);cn(g,.3,.4,0,0,2.3,0x2f7a35);cn(g,.8,.7,0,0,2.7,0xb5442f,12)},
mortar(g,b){cy(g,.85,.95,.4,0,0,0,0x8d8f95);cy(g,.55,.5,.35,0,0,.4,0x444450);const q=cy(g,.26,.34,.9,.1,0,.9,0x2b2b30);q.rotation.y=.8;q.position.set(.3,0,.9)},
wall(g,b,nb){bx(g,.86,.86,.5,0,0,0,0xb5b8be);bx(g,.62,.62,.12,0,0,.5,0xd7dadf);if(nb.x)bx(g,.9,.4,.3,.9,0,0,0xa1a4aa);if(nb.y)bx(g,.4,.9,.3,0,.9,0,0xa1a4aa)}};
function tree(x,y,k){const g=new T.Group(),w=new T.Group();w.scale.z=K;g.add(w);cy(w,.12,.16,.4,0,0,0,0x6b4626,{ol:0});
 if(k%3){cn(w,.55,.8,0,0,.35,0x2f8a3a);cn(w,.42,.7,0,0,.8,0x38a044)}else{sp(w,.5,0,0,.8,0x45b04a);sp(w,.35,.3,.1,1.05,0x56c055)}g.position.set(x,y,0);scene.add(g);return g}
function troopMesh(t,D){const g=new T.Group(),s=(D.r||8)/8,c=D.c;g.userData.s=s;const w=new T.Group();w.scale.set(s,s,K*s);g.add(w);
 const k=t.k;if(k=='wb'){sp(w,.22,0,0,.25,0x222);cy(w,.02,.02,.2,0,0,.45,0xffd24a,{em:0xff6a00,ol:0})}
 else{cy(w,.17,.2,.35,0,0,.05,c);sp(w,.15,0,0,.55,0xf5c8a0);
  if(k=='barb'){cn(w,.18,.18,0,0,.6,0xe0a030);bx(w,.05,.05,.5,.2,0,.25,0xdfe6ee)}
  if(k=='arch'){cn(w,.2,.28,0,0,.55,0xff6aa0);bx(w,.04,.04,.5,-.18,0,.2,0x8a5a2b)}
  if(k=='giant'){sp(w,.17,0,0,.62,0x8a4a1a);bx(w,.2,.3,.08,0,0,.45,0x6b4626)}
  if(k=='gob'){cn(w,.08,.2,.15,.1,.55,0x6fcf62);cn(w,.08,.2,-.15,.1,.55,0x6fcf62)}
  if(k=='king'){cy(w,.16,.16,.1,0,0,.7,0xffd24a,{em:0x553300});bx(w,.04,.4,.5,-.18,0,.15,0x7b2fa0)}}
 const sh=new T.Mesh(new T.CircleGeometry(.28*s,16),new T.MeshBasicMaterial({color:0,transparent:true,opacity:.28}));sh.position.z=.01;g.add(sh);scene.add(g);return g}
const M=new Map(),FX=[];let islandN=0,island=null,water=null,wtex=null;
function mkTex(c1,c2){const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');
 for(let i=0;i<4;i++){x.fillStyle=(i+(i>>1))%2?c1:c2;x.fillRect(i%2*64,(i>>1)*64,64,64)}
 x.fillStyle='rgba(255,255,255,.1)';for(let i=0;i<4;i++)x.fillRect(i%2*64,(i>>1)*64,64,4);
 x.fillStyle='rgba(0,70,0,.14)';for(let i=0;i<30;i++){const a=(i*53)%128,b=(i*97)%128;x.fillRect(a,b,2,5)}
 const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=4;return t}
function buildIsland(N){if(island)scene.remove(island);island=new T.Group();const w=new T.Group();w.scale.z=K;island.add(w);
 const L=N+1.6,gx=N/2;bx(w,L+.3,L+.3,.7,gx,gx,-.7,0x8a5a2b);bx(w,L,L,.06,gx,gx,0,0x7a5a36,{ol:0});
 const gt=mkTex('#79bd48','#6fb43f');gt.repeat.set(N/2,N/2);const gr=new T.Mesh(new T.PlaneGeometry(N,N),new T.MeshBasicMaterial({map:gt,side:T.DoubleSide}));gr.position.set(gx,gx,.075);
 w.add(gr);for(let i=0;i<N;i+=2)for(const[x,y]of[[i,-1.1],[i+1,N+1.1],[-1.1,i+1],[N+1.1,i]])island.add(tree(x+.5,y+.5,i+(x>0)));
 for(let i=0;i<14;i++){const a=(i*37%N),b=(i*61%N);if(i%3==0)sp(w,.12,a+.5,b+.5,.15,0xff7ab0,{ol:0});else if(i%3==1)sp(w,.1,a+.3,b+.7,.14,0xfff09a,{ol:0})}
 scene.add(island);islandN=N;
 if(!water){wtex=new T.CanvasTexture((()=>{const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.fillStyle='#2aa6d8';x.fillRect(0,0,128,128);x.strokeStyle='rgba(255,255,255,.35)';x.lineWidth=3;for(let i=0;i<5;i++){x.beginPath();x.arc((i*37)%128,(i*71)%128,14,3.6,5.8);x.stroke()}return c})());wtex.wrapS=wtex.wrapT=T.RepeatWrapping;wtex.repeat.set(30,30);
  water=new T.Mesh(new T.PlaneGeometry(300,300),new T.MeshBasicMaterial({map:wtex}));water.position.set(gx,gx,-.75*K/K);const wg=new T.Group();wg.scale.z=K;wg.add(water);scene.add(wg)}
 water.position.set(gx,gx,-.72)}
function burst(x,y,c,n){for(let i=0;i<n;i++){const m=new T.Mesh(new T.SphereGeometry(.18+Math.random()*.15,8,6),new T.MeshToonMaterial({color:i%2?c:0xd9d2c0,gradientMap:gm,transparent:true}));
 m.position.set(x,y,.3);const w=new T.Group();w.scale.z=K;w.add(m);scene.add(w);FX.push({w,m,vx:(Math.random()-.5)*4,vy:(Math.random()-.5)*4,vz:1+Math.random()*3,l:0})}}
function key(o){return o}
function sig(b,nb){return b.t+b.lv+(nb?nb.x+''+nb.y:'')}
function sync(){const A_=mode=='a',list=A_?E.b:S.b,seen=new Set(),walls=new Set();
 for(const b of list)if(b.t=='wall'&&b.hp>0)walls.add(b.x+','+b.y);
 for(const b of list){if(b.hp<=0)continue;seen.add(b);const nb=b.t=='wall'?{x:walls.has((b.x+1)+','+b.y)?1:0,y:walls.has(b.x+','+(b.y+1))?1:0}:null;let e=M.get(b);
  if(!e||e.s!=sig(b,nb)){if(e)scene.remove(e.g);const g=new T.Group(),w=new T.Group();w.scale.z=K;g.add(w);(MODEL[b.t]||MODEL.hut)(w,b,nb);
   const sh=new T.Mesh(new T.CircleGeometry(TY[b.t].s*.62,20),new T.MeshBasicMaterial({color:0,transparent:true,opacity:.25}));sh.position.z=.02;if(b.t!='wall')g.add(sh);
   if(b.lv>1&&b.t!='wall'&&b.t!='hall')flag(w,TY[b.t].s/2-.1,-TY[b.t].s/2+.1,.2,b.lv>2?0xb07aff:0xffd24a);
   scene.add(g);e={g,w,s:sig(b,nb),hp:b.hp};M.set(b,e)}
  const s=TY[b.t].s;e.g.position.set(b.x+s/2,b.y+s/2,0);const up=b.up>0&&b.t!='wall';e.w.scale.set(1,1,K*(up?.55+.05*Math.sin(performance.now()/180):1));
  e.g.visible=true;if(A_&&b.hp<b.max*.4&&Math.random()<.04)burst(b.x+s/2,b.y+s/2,0x555555,1)}
 for(const t of(A_&&A?A.tr:[])){if(t.hp<=0)continue;seen.add(t);let e=M.get(t);if(!e){e={g:troopMesh(t,TR[t.k]),t};M.set(t,e)}
  const D=TR[t.k],bob=t.mv?Math.abs(Math.sin(performance.now()/90))*5:0;e.g.position.set(t.x,t.y,(t.jh||0)+bob);e.g.rotation.z=Math.sin(performance.now()/120+t.x)*(t.mv?.12:0)}
 for(const[k,e]of M)if(!seen.has(k)){scene.remove(e.g);M.delete(k);if(mode=='a'&&k.t&&TY[k.t])burst(k.x+TY[k.t].s/2,k.y+TY[k.t].s/2,0x8a6a3e,16);else if(k.k)burst(k.x,k.y,0xffffff,4)}}
function setProj(){const W=LW(),H=LH(),z=cam_.z,a=2*z*18/W,b=2*z*9/H,c=2*z/H;
 cam3.projectionMatrix.set(a,-a,0,2*(cam_.x+z*OX)/W-1, -b,-b,c,1-2*(cam_.y+z*OY)/H, -.004,-.004,-.003,0, 0,0,0,1);
 cam3.projectionMatrixInverse.copy(cam3.projectionMatrix).invert()}
const cam_=(0,eval)('cam');
function render3d(){const W=cv.width,H=cv.height;if(c3.width!=W||c3.height!=H){ren.setPixelRatio(1);ren.setSize(W,H,false)}
 if(islandN!=N)buildIsland(N);sync();setProj();const t=performance.now()/1000;
 for(const o of spin){o.rotation.z=t*2;o.position.z+=Math.sin(t*3)*.0008}for(const f of wave)f.rotation.z=Math.sin(t*4+f.position.x)*.25;
 if(wtex){wtex.offset.x=t*.01;wtex.offset.y=t*.006}
 for(let i=FX.length-1;i>=0;i--){const f=FX[i];f.l+=.016;f.vz-=.1;f.m.position.x+=f.vx*.016;f.m.position.y+=f.vy*.016;f.m.position.z=Math.max(.05,f.m.position.z+f.vz*.016);f.m.material.opacity=Math.max(0,1-f.l/.8);f.m.scale.setScalar(1+f.l*1.5);
  if(f.l>.8){scene.remove(f.w);FX.splice(i,1)}}
 scene.traverse(o=>{o.frustumCulled=false});ren.render(scene,cam3)}
/* suprimir lo que el 2D dibujaba como cuerpo (terreno, edificios, tropas) mientras el 3D esté activo */
const TER=new Set(['#79bd48','#6fb43f','#7a5a36']);let ON=0;
const _f=g.fill.bind(g),_fr=g.fillRect.bind(g),_ft=g.fillText.bind(g);
g.fill=function(){if(ON&&TER.has(g.fillStyle))return;_f.apply(null,arguments)};
g.fillRect=function(x,y,w,h){if(ON&&w>=600&&h>=400)return;_fr(x,y,w,h)};
g.fillText=function(t,x,y){if(ON){const m=/(\d+)px/.exec(g.font);if(/serif/.test(g.font)&&m&&+m[1]>=20)return;if(t=='🌲')return}_ft(t,x,y)};
let inT=0;for(const n of['box','slab','stump','drGst','drEst','spr','drSword'])try{const o=eval(n);if(typeof o=='function')eval(n+'=function(){if(ON)return;return o.apply(this,arguments)}')}catch(e){}
const oT=drT;drT=function(t){const p=ON;if(p){}return oT.apply(this,arguments)};
const oD=draw;draw=function(){ON=0;if(!R.ok&&!R.tried){R.tried=1;try{buildIsland(N);R.ok=1}catch(e){console.error(e)}}
 if(R.ok&&!VT){try{render3d();ON=1;c3.style.display='block'}catch(e){console.error(e);R.ok=0;c3.style.display='none'}}else c3.style.display='none';
 try{oD()}finally{ON=0}};
window.CC3D=R})();
