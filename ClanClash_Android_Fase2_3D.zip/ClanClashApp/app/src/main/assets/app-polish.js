(function(){
const AC0=window.AudioContext||window.webkitAudioContext;if(AC0){
 window.AudioContext=function(){const c=new AC0();
  const comp=c.createDynamicsCompressor();comp.threshold.value=-18;comp.ratio.value=4;
  const eq=c.createBiquadFilter();eq.type='highshelf';eq.frequency.value=5000;eq.gain.value=3;
  const mg=c.createGain();mg.gain.value=.9;
  const len=c.sampleRate*.5|0,ir=c.createBuffer(2,len,c.sampleRate);
  for(let ch=0;ch<2;ch++){const d=ir.getChannelData(ch);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/len,3)}
  const rv=c.createConvolver();rv.buffer=ir;const wet=c.createGain();wet.gain.value=.16;
  const inp=c.createGain();inp.connect(eq);eq.connect(comp);eq.connect(rv);rv.connect(wet);wet.connect(comp);
  comp.connect(mg);mg.connect(c.destination);
  Object.defineProperty(c,'destination',{value:inp});
  document.addEventListener('pointerdown',()=>c.resume(),{passive:true});return c};
 window.AudioContext.prototype=AC0.prototype;window.webkitAudioContext=window.AudioContext}
const vib=ms=>{try{Android.vib(ms)}catch(e){}};
addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('button');
 if(b&&!b.disabled)vib(b.classList.contains('atk')?35:12)},{passive:true});
addEventListener('DOMContentLoaded',()=>{
 const st=document.createElement('style');st.textContent=`
 .rp{position:fixed;width:14px;height:14px;margin:-7px;border-radius:50%;border:3px solid #ffe9a8;pointer-events:none;z-index:99;animation:rp .5s ease-out forwards}
 @keyframes rp{to{transform:scale(5);opacity:0}}
 #top span.pill{box-shadow:0 3px 0 #05080e,0 0 12px rgba(255,213,74,.25),inset 0 2px 0 rgba(255,255,255,.22)}
 .card,.mbox,#msg>div{backdrop-filter:blur(6px)}
 body::after{content:"";position:fixed;inset:0;pointer-events:none;z-index:4;box-shadow:inset 0 0 90px rgba(0,0,0,.55)}
 .tcard:active,.tc:active{transform:scale(.94)}`;document.head.appendChild(st);
 addEventListener('pointerdown',e=>{const d=document.createElement('div');d.className='rp';d.style.left=e.clientX+'px';d.style.top=e.clientY+'px';document.body.appendChild(d);setTimeout(()=>d.remove(),520)},{passive:true})});
})();
