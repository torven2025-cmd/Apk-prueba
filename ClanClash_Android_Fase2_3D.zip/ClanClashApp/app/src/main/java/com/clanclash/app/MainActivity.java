package com.clanclash.app;
import android.app.Activity;import android.os.*;import android.view.*;import android.webkit.*;import android.graphics.Color;
public class MainActivity extends Activity{
 WebView w;
 @Override protected void onCreate(Bundle b){super.onCreate(b);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  w=new WebView(this);w.setBackgroundColor(Color.parseColor("#1c1109"));setContentView(w);
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
  s.setMediaPlaybackRequiresUserGesture(false);
  w.setOverScrollMode(View.OVER_SCROLL_NEVER);w.setLayerType(View.LAYER_TYPE_HARDWARE,null);
  w.addJavascriptInterface(new Object(){
   @JavascriptInterface public void vib(int ms){Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);
    if(v!=null){if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE));else v.vibrate(ms);}}
  },"Android");
  w.loadUrl("file:///android_asset/index.html");}
 @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);
  if(f)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
 @Override protected void onPause(){super.onPause();w.onPause();}
 @Override protected void onResume(){super.onResume();w.onResume();}
 @Override public void onBackPressed(){w.evaluateJavascript("(function(){var m=document.querySelector('[data-m2=close],.cx');if(m&&m.offsetParent){m.click();return 1}return 0})()",v->{if("0".equals(v))moveTaskToBack(true);});}
}
