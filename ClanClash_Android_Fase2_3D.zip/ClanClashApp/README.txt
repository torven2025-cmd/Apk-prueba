CLAN CLASH - Proyecto Android (Fase 2: 3D cartoon)
1) Abre la carpeta en Android Studio y espera el Gradle Sync.
2) Opcional (recomendado): descarga https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
   y guardalo como app/src/main/assets/three.min.js (así el 3D funciona sin internet).
   Si no está, la app lo carga del CDN. Si Three.js no carga, el juego usa el modo 2D original.
3) Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk
