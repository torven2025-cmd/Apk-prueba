# Clan Clash – APK Android

Proyecto Capacitor listo para compilar. El juego está en `www/index.html` (tu v11 + capa de mejoras).

## Opción A – Desde el navegador (sin instalar nada)
1. Crea un repositorio en GitHub y sube **todo el contenido** de esta carpeta (incluida `.github`).
2. Ve a **Actions → Build APK → Run workflow**.
3. Al terminar (~5 min) descarga **ClanClash-APK** en *Artifacts* → dentro está `app-debug.apk`.
4. Instálalo en el teléfono (permite "instalar apps desconocidas").

## Opción B – En tu PC (Node 22 + JDK 21 + Android Studio)
```
npm install
npx cap add android
npx capacitor-assets generate --android
node scripts/patch-android.mjs
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Para publicar en Play Store
Genera un AAB firmado: `./gradlew bundleRelease` y firma con tu keystore.

## Mejoras incluidas
- **Audio:** compresor + reverb + filtro suave, paneo estéreo aleatorio, variación de tono, SFX con campanillas y capas (UI, monedas, victoria, derrota, explosiones, cuerno).
- **Gráficos:** viñeta, luz solar, sombras de nubes, luciérnagas (brasas en batalla), tinte según hora del día y ondas al tocar.
- **UI/App:** pantalla de carga con "Toca para jugar", vibración háptica, pantalla inmersiva, botón Atrás de Android, pausa de audio y guardado al salir, sin selección de texto ni zoom.
- Menú ⚙: nuevos interruptores de **Vibración** y **Efectos visuales**.

## Notas
- La fuente *Lilita One* se descarga de Google Fonts; sin internet usa una de respaldo. Para offline, guarda el .ttf en `www/fonts/` y añade un `@font-face`.
- El juego corre en modo offline (`OFFLINE=true`); quité la librería de Supabase porque no se usaba.
